package main.java.com.example;

public class T3
{
    public double Teht3C()
    {
        double rad = 3;

        double crclarea = (Math.PI * rad * rad);

        return crclarea;
    }
    public double Teht3S()
    {
        double sqrlength = 3;

        double sqrarea = (sqrlength * sqrlength);

        return sqrarea;
    }
    public double Teht3T()
    {
        double height = 3;
        double base = 3;

        double trianglearea = (base * height / 2);

        return trianglearea;
    }
}